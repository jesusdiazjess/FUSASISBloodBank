﻿using $safeprojectname$.BLL;
using $safeprojectname$.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$.UI
{
    public partial class frmUsers : Form
    {
        public frmUsers()
        {
            InitializeComponent();
        }

        //CREATE OBJECT OF userBLL and userDAL
        userBLL u = new userBLL();
        userDAL u = new userDAL(); //error

        string imageName = "no.image.jpg";

        private void pictureBoxClose_Click(object sender, EventArgs e)
        {
            //ADD FUNCTIONALITY FOR CLOSE TO THIS FORM
            this.Hide();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //STEP 1: GET THE VALUES FROM UI
            u.full_name = txtFullName.Text;
            u.email = txtEmail.Text;
            u.username = txtUsername.Text;
            u.password = txtPassword.Text;
            u.contact = txtContact.Text;
            u.address = txtAddress.Text;
            u.added_date = DateTime.Now;
            u.image_name = imageName;

            //STEP 2: ADDING THE VALUES FROM UI TO DATABASE
            //CREATE A BOOLEAN VARIABLE TO CHECK WHETHER THE DATA IS INSERTED SUCCESSFULLY OR NOT
            bool success = dal.Insert(u);

            //STEP 3: CHECK WETHER THE DATA IS INSERTED SUCCESSFULLY OR NOT
            if (success == true)
            {
                //DATA OR USER ADDED SUCCESSFULLY
                MessageBox.Show("New User Added Succesfully.");
            }
            else
            {
                //FAILED TO ADD USER
                MessageBox.Show("Failed to Add New User.");
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

        }
    }
}
