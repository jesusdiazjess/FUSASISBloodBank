﻿using BloodBankManagementSystem.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BloodBankManagementSystem
{
    public partial class frmHOME : Form
    {
        public frmHOME()
        {
            InitializeComponent();
        }

        private void pictureBoxClose_Click(object sender, EventArgs e)
        {
            //CODE FOR CLOSED APPLICATION
            this.Hide();
        }

        private void uSERSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //OPEN USERS FORM
            frmUsers users = new frmUsers();
            users.Show();

        }
    }
}
