﻿using BloodBankManagementSystem.BLL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BloodBankManagementSystem.DAL
{
    class userDAL
    {
        //CREATE A STATIC STRING TO CONNECT DATABASE
        static string myconnstrng = ConfigurationManager.ConnectionStrings["connstrng"].ConnectionString;

        #region SELECT data from database
        public DataTable Select()
        {
            //CREATE AN OBJECT TO CONNECT DATABASE
            SqlConnection conn = new SqlConnection();

            //CREATE A DATA TABLE TO HOLD THE DATA FROM DATABASE
            DataTable dt = new DataTable();

            try
            {
                //WRITE SQL QUERY TO GET DATA FROM DATABASE
                String sql = "SELECT * FROM tbl_users";

                //CREATE SQL COMMAND TO EXECUTE QUERY
                SqlCommand cmd = new SqlCommand(sql, conn);

                //CREATE SQL DATA ADAPTER TO HOLD THE DATA FROM DATABASE TEMPORARILY
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                //OPEN DATABASE CONNECTION
                conn.Open();

                //TRANSFER DATA FROM SQL DATA ADAPTER TO DATA TABLE
                adapter.Fill(dt);
            }
            catch (Exception ex)
            {
                //DISPLAY ERROR MESSAGE IF THERE'S ANY EXCEPTIONALS ERRORS
                MessageBox.Show(ex.Message);
            }
            finally
            {
                //CLOSE DATABASE CONNECTION
                conn.Close();
            }


            return dt;
        }
        #endregion

        #region Inserta Data into Database for User Module
        public bool Insert(userBLL u)
        {
            //CREATE A BOOLEAN VARIABLE AND SET ITS DEFAULT VALUE TO FALSE
            bool isSuccess = false;

            //CREATE AN OBJECT OF SQLCONNECTION TO CONNECT DATABASE
            SqlConnection conn = new SqlConnection();

            try
            {
                //CREATE A STRING VARIABLE TO STORE THE QUERY THE INSERT QUERY
                String sql = "INSERT INTO tbl_users(username, email, password, full_name, contact, address, added_date, image_name) VALUES (@username, @email, @password, @full_name, @contact, @address, @added_date, @image_name)";

                //CREATE A SQL COMMAND TO PASS THE VALUE IN OUR QUERY
                SqlCommand cmd = new SqlCommand(sql, conn);

                //CREATE THE PARAMETERS TO PASS AND GET THE VALUES FROM UI AND PASS IT ON SQL QUERY ABOVE
                cmd.Parameters.AddWithValue("@username", u.username);
                cmd.Parameters.AddWithValue("@email", u.email);
                cmd.Parameters.AddWithValue("@paasword", u.password);
                cmd.Parameters.AddWithValue("@full_name", u.full_name);
                cmd.Parameters.AddWithValue("@contact", u.contact);
                cmd.Parameters.AddWithValue("@address", u.address);
                cmd.Parameters.AddWithValue("@added_date", u.added_date);
                cmd.Parameters.AddWithValue("@image_name", u.image_name);

                //OPEN DATABASE CONNECTION
                conn.Open();

                //CREATE AN INTEGER VARIABLE TO HOLD THE VALUE AFTER THE QUERY IS EXECUTED
                int rows = cmd.ExecuteNonQuery();

                //THE VALUES OF ROWS WILL BE GREATER THAN 0 IF THE QUERY IS EXECUTED SUCCESSFULLY
                //ELSE IT'LL BE 0

                if (rows > 0)
                {
                    //QUERY EXECUTED SUCCESSFULLY
                    isSuccess = true;
                }
                else
                {
                    //FAILED TO EXECUTE QUERY
                    isSuccess = false;
                }
            }
            catch (Exception ex)
            {
                //DISPLAY ERROR MESSAGE IF THERE'S ANY EXCEPTIONAL ERRORS
                MessageBox.Show(ex.Message);
            }
            finally
            {
                //CLOSE DATABASE CONNECTION
                conn.Close();
            }

            return isSuccess;
        }
        #endregion

        #region UPDATE data in database (User Module)
        public bool Update(userBLL u)
        {
            //CREATE A BOOLEAN VARIABLE AND SETS ITS DAFAULT VALUE TO FALSE
            bool isSuccess = false;

            //CREATE AN OBJECT FOR DATABASE CONNECTION
            SqlConnection conn = new SqlConnection();

            try
            {
                //CREATE A STRING VARAIBLE TO HOLD THE SQL QUERY
                string sql = "UPDATE tbl_users SET username=@username, email=@email, password=@password, full_name=@full_name, contact=@contact, address=@address, added_date=@added_date, image_name=@image_name WHERE user_id=@user_id";

                //CREATE SQL COMMAND TO EXECUTE QUERY AND ALSO PASS THE VALUES TO SQL QUERY
                SqlCommand cmd = new SqlCommand(sql, conn);

                //NOW PAST THE VALUES TO SQL QUERY
                cmd.Parameters.AddWithValue("@username", u.username);
                cmd.Parameters.AddWithValue("@email", u.email);
                cmd.Parameters.AddWithValue("@password", u.password);
                cmd.Parameters.AddWithValue("@full_name", u.full_name);
                cmd.Parameters.AddWithValue("@contact", u.contact);
                cmd.Parameters.AddWithValue("@address", u.address);
                cmd.Parameters.AddWithValue("@added_date", u.added_date);
                cmd.Parameters.AddWithValue("@image_name", u.image_name);
                cmd.Parameters.AddWithValue("@user_id", u.user_id);

                //CREATE AN INTEGER VARIABLE TO HOLD THE VALUE AFTER THE QUERY IS EXECUTED
                int rows = cmd.ExecuteNonQuery();

                //IF THE QUERY IS EXECUTED SUCCESSFULLY THEN THE VALUE OF ROWS WILL BE GREATER THAN 0
                //ELSE IT'LL 0

                if (rows > 0)
                {
                    //QUERY EXECUTED SUCCESSFULLY
                    isSuccess = true;
                }
                else
                {
                    //FAILED TO EXECUTE QUERY
                    isSuccess = false;
                }
            }

            catch (Exception ex)
            {
                //DISPLAY ERROR MESSAGE IF THERE'S ANY EXCEPTIONAL ERRORS
                MessageBox.Show(ex.Message);
            }

            finally
            {
                //CLOSE DATABASE CONNECTION
                conn.Close();
            }

            return isSuccess;
        }
        #endregion

        #region Delete data from Database (User Module)
        public bool Delete(userBLL u)
        {
            //CREATE A BOOLEAN VARIABLE AND SET ITS DEFAULT VALUE TO FALSE
            bool isSuccess = false;

            //CREATE AN OBJECT FOR SQL CONNECTION
            SqlConnection conn = new SqlConnection();

            try
            {
                //CREATE A STRING VARIABLE TO HOLD THE SQL QUERY TO DELETE DATA
                String sql = "DELETE FROM tbl_users WHERE user_id=@user_id";

                //CREATE SQL COMMAND TO EXECUTE THE QUERY
                SqlCommand cmd = new SqlCommand(sql, conn);

                //PASS THE VALUE THROUGH PARAMETERS
                cmd.Parameters.AddWithValue("@user_id", u.user_id);

                //CREATE AN INTEGER VARIABLE TO HOLD THE VALUE AFTER QUERY IS EXECUTED
                int rows = cmd.ExecuteNonQuery();

                //IF THE QUERY IS EXECUTED SUCCESSFULLY THEN THE VALUE OF ROWS WILL BE GREATER THAN ZERO(0)
                //ELSE IT'LL BE ZERO(0)

                if (rows > 0)
                {
                    //QUERY EXECUTED SUCCESSFULLY
                    isSuccess = true;
                }
                else
                {
                    //FAILED TO EXECUTE QUERY
                    isSuccess = false;
                }
            }
            catch (Exception ex)
            {
                //DISPLAY ERROR MESSAGE IF THERE'S ANY EXCEPTIONAL ERRORS
                MessageBox.Show(ex.Message);
            }
            finally
            {
                //CLOSE DATABASE CONNECTION
                conn.Close();
            }

            return isSuccess;
        }
        #endregion
    }
}
