create database bloodbank20;

create table newDonor20(
did int NOT NULL IDENTITY(1,1) primary key,
dname varchar(200) not null,
dob varchar(50) not null,
fname varchar(200) not null,
mname varchar(200) not null,
mobile bigint,
gender varchar(25) not null,
city varchar(50) not null,
daddress varchar(50) not null,
bloodgroup varchar(50) not null
)

select * from newDonor20
