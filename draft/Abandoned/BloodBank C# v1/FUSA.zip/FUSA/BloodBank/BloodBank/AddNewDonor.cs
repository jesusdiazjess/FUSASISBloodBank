﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BloodBank
{
    public partial class AddNewDonor : Form
    {
        Function fn = new Function();
        public AddNewDonor()
        {
            InitializeComponent();
        }

        private void AddNewDonor_Load(object sender, EventArgs e)
        {
            String query = "select max(did) from newDonor20";
            DataSet ds = fn.getData(query);
            int count = int.Parse(ds.Tables[0].Rows,[0][0].ToString());
            labelNewID.Text = (count+1).ToString();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtName.Text != "" && txtDOB.Text != "" && txtFather.Text != "" && txtMother.Text != "" && txtMobile.Text != "" && txtGender.Text != "" && txtCity.Text != "" && txtAddress.Text != "" && txtBloodGroup.Text != "")
            {
                String dname = txtName.Text;
                String dob = txtDOB.Text;
                String fname = txtFather.Text;
                String mname = txtMother.Text;
                Int64 mobile = Int64.Parse(txtMobile.Text);
                String gender = txtGender.Text;
                String city = txtCity.Text;
                String daddress = txtAddress.Text;
                String bloodgroup = txtBloodGroup.Text;

                String query = "insert into newDonor20 (dname,dob,fname,mname,mobile,gender,city,daddress,bloodgroup) values('" + dname + "', '" + dob + "', '" + txtFather + "', '" + txtMother + "', '" + txtMobile + "', '" + txtGender + "', '" + txtCity + "', '" + txtAddress + "', '" + txtBloodGroup + "')";
                fn.setDate(query);
            }
            else
            {
                MessageBox.Show("Please fill all the Fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
