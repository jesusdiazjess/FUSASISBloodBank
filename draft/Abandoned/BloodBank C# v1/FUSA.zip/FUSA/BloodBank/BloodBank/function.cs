﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BloodBank
{
    class Function
    {
        private readonly string connectionString = "data source=DESKTOP-Q24SDSL;database=bloodbank;integrated security=True";

        protected SqlConnection GetConnection()
        {
            SqlConnection con = new SqlConnection(connectionString);
            return con;
        }

        public DataSet GetData(string query) // GET DATA FROM DATABASE
        {
            using (SqlConnection con = GetConnection())
            {
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                return ds;
            }
        }

        public void SetDate(string query) // Insert Deletion Updation 
        {
            {
                SqlConnection con = GetConnection();
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Connection = con;
                con.Open();
                cmd.CommandText = query;
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data Processed Successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        internal DataSet getData(string query)
        {
            throw new NotImplementedException();
        }

        internal void setDate(string query)
        {
            throw new NotImplementedException();
        }
    }
}
